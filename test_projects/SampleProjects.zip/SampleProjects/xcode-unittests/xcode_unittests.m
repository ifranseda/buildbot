//
//  xcode_unittests.m
//  xcode-unittests
//
//  Created by Christopher Blatchley on 3/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "xcode_unittests.h"

@implementation xcode_unittests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testFailing
{
    //STFail(@"Unit tests are not implemented yet in xcode-unittests");
}

-(void)testPassing
{
    STAssertTrue(YES, @"Always passing");
}

@end
