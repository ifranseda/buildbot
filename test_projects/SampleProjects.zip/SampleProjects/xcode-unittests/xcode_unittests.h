//
//  xcode_unittests.h
//  xcode-unittests
//
//  Created by Christopher Blatchley on 3/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface xcode_unittests : SenTestCase

@end
